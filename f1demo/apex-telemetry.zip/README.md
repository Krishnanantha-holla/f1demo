# Apex Telemetry

High-fidelity live Formula 1 visual race control, telemetry, track-map, and analysis dashboard. Built with React 19, Vite 6, Tailwind v4, and lucide-react.

## Features

- Live timing leaderboard with sector-by-sector classification (session-best vs personal-best)
- Animated SVG Sakhir track map with per-driver beacons and DRS-zone overlay
- Side-by-side telemetry comparator (RPM gauge, throttle/brake bars, 30-tick speed trace)
- Driver and constructor standings with championship bars and projection card
- Engineering audit console with simulated boundary delta logs
- Carbon-fibre themed dark UI with prefers-reduced-motion support

## Run locally

Prerequisites: Node 18+.

```bash
npm install
cp .env.example .env.local   # only if you wire up @google/genai
npm run dev
```

Then open http://localhost:3000.

## Scripts

| Command | What it does |
| --- | --- |
| `npm run dev` | Start the Vite dev server on port 3000 |
| `npm run build` | Produce a production build in `dist/` |
| `npm run preview` | Serve the production build locally |
| `npm run typecheck` | Run TypeScript without emit |

## Project layout

```
src/
  App.tsx                 # Top-level shell, nav, and simulation clock
  main.tsx                # React entry
  index.css               # Tailwind v4 theme tokens + carbon-card styles
  types.ts                # Driver / SessionInfo / IntelMessage models
  data.ts                 # Seed data + simulateDriversTelemetry tick
  components/
    DashboardView.tsx
    LiveTimingView.tsx
    TrackMapView.tsx
    TelemetryView.tsx
    StandingsView.tsx
    AnalysisView.tsx
```

## Notes

The telemetry feed is a deterministic-ish simulator. Lap times, sectors, gaps, and positions all roll over each lap, so leaving the page open will reshuffle the leaderboard.
