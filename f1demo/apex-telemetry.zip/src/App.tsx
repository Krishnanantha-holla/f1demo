import { useState, useEffect, useRef } from 'react';
import { AppTab, Driver, SessionInfo, IntelMessage } from './types';
import {
  INITIAL_DRIVERS,
  INITIAL_SESSION,
  INTEL_MESSAGES,
  simulateDriversTelemetry,
} from './data';
import DashboardView from './components/DashboardView';
import LiveTimingView from './components/LiveTimingView';
import TrackMapView from './components/TrackMapView';
import TelemetryView from './components/TelemetryView';
import StandingsView from './components/StandingsView';
import AnalysisView from './components/AnalysisView';
import {
  Timer,
  Map,
  Activity,
  TrendingUp,
  Wrench,
  Settings,
  HelpCircle,
  User,
  LayoutGrid,
  Pause,
  Play,
} from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<AppTab>('dashboard');
  const [drivers, setDrivers] = useState<Driver[]>(INITIAL_DRIVERS);
  const [session, setSession] = useState<SessionInfo>(INITIAL_SESSION);
  const [intel] = useState<IntelMessage[]>(INTEL_MESSAGES);
  const [selectedDriverId, setSelectedDriverId] = useState<string | null>(
    INITIAL_DRIVERS[0]?.id ?? null,
  );
  const [isSimulating, setIsSimulating] = useState<boolean>(true);

  // Derive the live selected driver object from the current drivers array.
  // Avoids stale snapshots and the infinite-loop hazard of storing a Driver in state.
  const selectedDriver: Driver | null =
    drivers.find(d => d.id === selectedDriverId) ?? null;

  const setSelectedDriver = (driver: Driver | null) => {
    setSelectedDriverId(driver?.id ?? null);
  };

  // Throttled session-level latency jitter so the badge breathes a little.
  const tickRef = useRef(0);

  // Set up the dynamic simulation clock
  useEffect(() => {
    if (!isSimulating) return;

    const intervalId = window.setInterval(() => {
      tickRef.current += 1;
      setDrivers(prev => simulateDriversTelemetry(prev));

      setSession(prev => {
        const nextTime = Math.max(0, prev.remainingTime - 1);
        // Recalculate current lap from total/remaining so the HUD progresses.
        const totalSeconds = 3600; // 1h reference window
        const lapsDone = Math.min(
          prev.totalLaps,
          Math.floor(((totalSeconds - nextTime) / totalSeconds) * prev.totalLaps),
        );
        const wobble = (Math.sin(tickRef.current / 4) + 1) * 6;
        return {
          ...prev,
          remainingTime: nextTime,
          currentLap: Math.max(prev.currentLap, lapsDone),
          apiLatency: Math.round(8 + wobble),
        };
      });
    }, 500);

    return () => window.clearInterval(intervalId);
  }, [isSimulating]);

  // Handle simulation resetting
  const handleResetSim = () => {
    setIsSimulating(false);
    setDrivers(INITIAL_DRIVERS);
    setSession(INITIAL_SESSION);
    setSelectedDriverId(INITIAL_DRIVERS[0]?.id ?? null);
  };

  // Main layout router
  const renderTabContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return (
          <DashboardView 
            drivers={drivers} 
            session={session} 
            intel={intel} 
            onNavigate={setActiveTab} 
            selectedDriver={selectedDriver}
            setSelectedDriver={setSelectedDriver}
          />
        );
      case 'live-timing':
        return (
          <LiveTimingView 
            drivers={drivers} 
            session={session} 
            selectedDriver={selectedDriver}
            setSelectedDriver={setSelectedDriver}
            isSimulating={isSimulating}
            setIsSimulating={setIsSimulating}
            onResetSim={handleResetSim}
          />
        );
      case 'track-map':
        return (
          <TrackMapView 
            drivers={drivers} 
            selectedDriver={selectedDriver}
            setSelectedDriver={setSelectedDriver}
          />
        );
      case 'telemetry':
        return (
          <TelemetryView 
            drivers={drivers} 
            selectedDriver={selectedDriver}
            setSelectedDriver={setSelectedDriver}
          />
        );
      case 'standings':
        return <StandingsView drivers={drivers} />;
      case 'analysis':
        return <AnalysisView drivers={drivers} intel={intel} />;
      default:
        // Fallback placeholder
        return (
          <div className="carbon-card rounded-lg p-10 text-center text-xs font-mono text-on-surface-variant">
            Under active construction. Toggle other available screens.
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-background-carbon text-on-surface antialiased overflow-x-hidden pb-20 md:pb-6">
      
      {/* TopNavBar */}
      <nav id="top_nav_bar" className="fixed top-0 right-0 left-0 md:left-64 h-16 z-40 border-b border-white/5 bg-surface-container flex justify-between items-center px-4 backdrop-blur-md bg-opacity-95">
        <div className="flex items-center gap-6">
          <span 
            className="font-sans font-black italic text-f1-red text-lg md:text-xl tracking-tight cursor-pointer"
            onClick={() => setActiveTab('dashboard')}
          >
            TELEMETRY HUB
          </span>
          
          {/* Main Desktop sub-headers */}
          <div className="hidden md:flex gap-4">
            <button 
              onClick={() => setActiveTab('dashboard')}
              className={`pb-1 font-mono text-xs tracking-wider uppercase font-bold transition-transform ${activeTab === 'dashboard' ? 'text-f1-red border-b-[2px] border-f1-red scale-95' : 'text-on-surface-variant hover:text-white'}`}
            >
              Dashboard
            </button>
            <button 
              onClick={() => setActiveTab('analysis')}
              className={`pb-1 font-mono text-xs tracking-wider uppercase font-bold transition-transform ${activeTab === 'analysis' ? 'text-f1-red border-b-[2px] border-f1-red scale-95' : 'text-on-surface-variant hover:text-white'}`}
            >
              Analysis
            </button>
            <button 
              onClick={() => setActiveTab('live-timing')}
              className={`pb-1 font-mono text-xs tracking-wider uppercase font-bold transition-transform ${activeTab === 'live-timing' ? 'text-f1-red border-b-[2px] border-f1-red scale-95' : 'text-on-surface-variant hover:text-white'}`}
            >
              Live Monitor
            </button>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <span className="font-mono text-[11px] text-on-surface-variant/75 hidden lg:block uppercase bg-white/5 border border-white/5 px-2 py-1 rounded">
            API LATENCY: {session.apiLatency}ms
          </span>
          <button
            onClick={() => setIsSimulating(!isSimulating)}
            className={`font-sans font-bold text-[10px] tracking-widest uppercase px-3 py-2 rounded-sm transition-colors cursor-pointer text-white flex items-center gap-1.5 ${isSimulating ? 'bg-f1-red animate-pulse' : 'bg-white/5 border border-white/10 hover:bg-white/10'}`}
            aria-pressed={isSimulating}
            aria-label={isSimulating ? 'Pause telemetry stream' : 'Resume telemetry stream'}
          >
            {isSimulating ? <Pause size={11} /> : <Play size={11} fill="currentColor" />}
            <span className={`w-1.5 h-1.5 rounded-full ${isSimulating ? 'bg-white animate-ping' : 'bg-white/50'}`} />
            {isSimulating ? 'LIVE' : 'PAUSED'}
          </button>
          <div className="flex gap-2 text-on-surface-variant/80">
            <Settings size={15} className="cursor-pointer hover:text-f1-red transition-colors" />
            <HelpCircle size={15} className="cursor-pointer hover:text-f1-red transition-colors" />
            <User size={15} className="cursor-pointer hover:text-f1-red transition-colors" />
          </div>
        </div>
      </nav>

      {/* SideNavBar (Desktop sidebar deck) */}
      <aside id="side_nav_bar" className="h-screen w-64 fixed left-0 top-0 overflow-y-auto hidden md:flex flex-col border-r border-white/5 bg-surface-dim z-50">
        <div className="p-4 border-b border-white/5 bg-surface-low flex flex-col gap-1">
          <h1 className="font-sans font-black tracking-tighter text-f1-red text-base uppercase leading-tight">
            F1 RACE CONTROL
          </h1>
          <p className="font-mono text-[9px] tracking-wider text-on-surface-variant/70 uppercase">
            Active: {session.country}
          </p>
        </div>

        {/* Dynamic primary tab anchors */}
        <nav className="flex flex-col h-full gap-1 py-4">
          <button 
            onClick={() => setActiveTab('live-timing')}
            className={`flex items-center px-5 py-3.5 font-mono text-xs uppercase font-bold text-left tracking-wider transition-all border-l-4 ${activeTab === 'live-timing' ? 'bg-f1-red/10 border-f1-red text-f1-red font-extrabold' : 'border-transparent text-on-surface-variant hover:text-white hover:bg-white/5'}`}
          >
            <Timer size={13} className="mr-3" />
            Live Timing
          </button>
          <button 
            onClick={() => setActiveTab('track-map')}
            className={`flex items-center px-5 py-3.5 font-mono text-xs uppercase font-bold text-left tracking-wider transition-all border-l-4 ${activeTab === 'track-map' ? 'bg-f1-red/10 border-f1-red text-f1-red font-extrabold' : 'border-transparent text-on-surface-variant hover:text-white hover:bg-white/5'}`}
          >
            <Map size={13} className="mr-3" />
            Track Map
          </button>
          <button 
            onClick={() => setActiveTab('telemetry')}
            className={`flex items-center px-5 py-3.5 font-mono text-xs uppercase font-bold text-left tracking-wider transition-all border-l-4 ${activeTab === 'telemetry' ? 'bg-f1-red/10 border-f1-red text-f1-red font-extrabold' : 'border-transparent text-on-surface-variant hover:text-white hover:bg-white/5'}`}
          >
            <Activity size={13} className="mr-3" />
            Telemetry
          </button>
          <button 
            onClick={() => setActiveTab('standings')}
            className={`flex items-center px-5 py-3.5 font-mono text-xs uppercase font-bold text-left tracking-wider transition-all border-l-4 ${activeTab === 'standings' ? 'bg-f1-red/10 border-f1-red text-f1-red font-extrabold' : 'border-transparent text-on-surface-variant hover:text-white hover:bg-white/5'}`}
          >
            <TrendingUp size={13} className="mr-3" />
            Standings
          </button>
          <button 
            onClick={() => setActiveTab('analysis')}
            className={`flex items-center px-5 py-3.5 font-mono text-xs uppercase font-bold text-left tracking-wider transition-all border-l-4 ${activeTab === 'analysis' ? 'bg-f1-red/10 border-f1-red text-f1-red font-extrabold' : 'border-transparent text-on-surface-variant hover:text-white hover:bg-white/5'}`}
          >
            <Wrench size={13} className="mr-3" />
            Engineering
          </button>
        </nav>
        
        {/* Dynamic fast stats panel at sidebar base */}
        {selectedDriver && (
          <div className="p-4 border-t border-white/5 bg-black/35 font-mono text-[10px] flex flex-col gap-1.5 mt-auto">
            <div className="flex justify-between uppercase">
              <span className="text-on-surface-variant/70">Selected car</span>
              <span className="font-extrabold text-[#fff]" style={{ color: selectedDriver.teamColor }}>
                {selectedDriver.code} (#{selectedDriver.number})
              </span>
            </div>
            <div className="flex justify-between uppercase">
              <span className="text-on-surface-variant/70">Live Velocity</span>
              <span className="font-bold text-on-surface">{selectedDriver.speed} KM/H</span>
            </div>
            <div className="flex justify-between uppercase">
              <span className="text-on-surface-variant/70">Tire State</span>
              <span className="font-bold text-white/90">{selectedDriver.tyre} Compound</span>
            </div>
          </div>
        )}
      </aside>

      {/* Main Content Area Canvas Container */}
      <main id="main_content_area" className="md:ml-64 pt-20 p-4 md:p-6 lg:p-8">
        {renderTabContent()}
      </main>

      {/* BottomNavBar (Mobile-only bottom dock reflows) */}
      <nav id="bottom_nav_bar" className="fixed bottom-0 w-full z-50 md:hidden border-t border-white/5 bg-surface-container bg-opacity-95 backdrop-blur-md flex justify-around items-center h-16 pb-safe">
        <button 
          onClick={() => setActiveTab('live-timing')}
          className={`flex flex-col items-center justify-center p-2 flex-1 ${activeTab === 'live-timing' ? 'text-f1-red' : 'text-on-surface-variant'}`}
        >
          <Timer size={14} />
          <span className="font-mono text-[9px] mt-1 font-bold">Timing</span>
        </button>
        <button 
          onClick={() => setActiveTab('track-map')}
          className={`flex flex-col items-center justify-center p-2 flex-1 ${activeTab === 'track-map' ? 'text-f1-red' : 'text-on-surface-variant'}`}
        >
          <Map size={14} />
          <span className="font-mono text-[9px] mt-1 font-bold">Track</span>
        </button>
        <button 
          onClick={() => setActiveTab('dashboard')}
          className={`flex flex-col items-center justify-center p-2 flex-1 rounded ${activeTab === 'dashboard' ? 'text-f1-red bg-white/5 scale-95 font-black' : 'text-on-surface-variant'}`}
        >
          <LayoutGrid size={15} />
          <span className="font-mono text-[9px] mt-1 font-bold">Home</span>
        </button>
        <button 
          onClick={() => setActiveTab('telemetry')}
          className={`flex flex-col items-center justify-center p-2 flex-1 ${activeTab === 'telemetry' ? 'text-f1-red' : 'text-on-surface-variant'}`}
        >
          <Activity size={14} />
          <span className="font-mono text-[9px] mt-1 font-bold">Telemetry</span>
        </button>
        <button 
          onClick={() => setActiveTab('standings')}
          className={`flex flex-col items-center justify-center p-2 flex-1 ${activeTab === 'standings' ? 'text-f1-red' : 'text-on-surface-variant'}`}
        >
          <TrendingUp size={14} />
          <span className="font-mono text-[9px] mt-1 font-bold">Standings</span>
        </button>
      </nav>

    </div>
  );
}
