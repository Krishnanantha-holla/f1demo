import { useState, useEffect } from 'react';
import { Driver, SessionInfo, IntelMessage } from '../types';
import { Timer, AlertOctagon, TrendingUp, ChevronRight, Award, Flame } from 'lucide-react';

interface DashboardViewProps {
  drivers: Driver[];
  session: SessionInfo;
  intel: IntelMessage[];
  onNavigate: (tab: any) => void;
  selectedDriver: Driver | null;
  setSelectedDriver: (driver: Driver | null) => void;
}

export default function DashboardView({
  drivers,
  session,
  intel,
  onNavigate,
  selectedDriver,
  setSelectedDriver,
}: DashboardViewProps) {
  // Countdown simulation
  const [countdown, setCountdown] = useState({
    days: 2,
    hours: 14,
    minutes: 45,
    seconds: 12,
  });

  useEffect(() => {
    const interval = setInterval(() => {
      setCountdown(prev => {
        if (prev.seconds > 0) {
          return { ...prev, seconds: prev.seconds - 1 };
        } else if (prev.minutes > 0) {
          return { ...prev, minutes: prev.minutes - 1, seconds: 59 };
        } else if (prev.hours > 0) {
          return { ...prev, hours: prev.hours - 1, minutes: 59, seconds: 59 };
        } else if (prev.days > 0) {
          return { ...prev, days: prev.days - 1, hours: 23, minutes: 59, seconds: 59 };
        }
        return { days: 0, hours: 0, minutes: 0, seconds: 0 };
      });
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  const top5Drivers = [...drivers]
    .sort((a, b) => b.points - a.points)
    .slice(0, 5);

  const getIntensityStyle = (type: string) => {
    switch (type) {
      case 'alert': return 'text-red-500 border-red-500/20 bg-red-950/20';
      case 'warning': return 'text-amber-500 border-amber-500/20 bg-amber-950/20';
      case 'speed': return 'text-blue-500 border-blue-500/20 bg-blue-950/20';
      default: return 'text-emerald-500 border-emerald-500/20 bg-emerald-950/20';
    }
  };

  return (
    <div className="flex flex-col gap-5 animate-fade-in">
      {/* Live Active Bar */}
      <div className="bg-f1-red text-white py-2 px-4 rounded-lg flex items-center justify-between shadow-lg live-glow">
        <div className="flex items-center gap-3">
          <span className="relative flex h-3 w-3">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-white opacity-75"></span>
            <span className="relative inline-flex rounded-full h-3 w-3 bg-white"></span>
          </span>
          <span className="font-sans font-bold tracking-widest text-xs uppercase">
            LIVE TELEMETRY STREAM ACTIVE: {session.sessionName}
          </span>
        </div>
        <div className="hidden sm:flex items-center gap-5 text-xs text-red-100 font-mono">
          <span>AIR: {session.airTemp.toFixed(1)}°C</span>
          <span>TRACK: {session.trackTemp.toFixed(1)}°C</span>
          <span>WIND: {session.windSpeed} km/h {session.windDirection}</span>
        </div>
      </div>

      {/* Bento Grid Layout */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
        
        {/* COUNTDOWN TIMER */}
        <div className="col-span-1 md:col-span-4 carbon-card rounded-lg p-5 flex flex-col justify-between h-48">
          <div className="flex items-center justify-between">
            <span className="font-mono text-xs font-bold tracking-wider text-on-surface-variant uppercase">
              NEXT SESSION START
            </span>
            <Timer size={14} className="text-on-surface-variant opacity-70" />
          </div>
          <div className="flex gap-4 items-end my-auto">
            <div className="flex flex-col">
              <span className="font-mono font-black text-3xl md:text-4xl text-f1-red leading-none">
                {String(countdown.days).padStart(2, '0')}
              </span>
              <span className="font-sans text-[10px] font-bold text-on-surface-variant mt-1">DAYS</span>
            </div>
            <span className="font-mono text-2xl text-on-surface-variant pb-1">:</span>
            <div className="flex flex-col">
              <span className="font-mono font-semibold text-3xl md:text-4xl text-on-surface leading-none">
                {String(countdown.hours).padStart(2, '0')}
              </span>
              <span className="font-sans text-[10px] font-bold text-on-surface-variant mt-1">HRS</span>
            </div>
            <span className="font-mono text-2xl text-on-surface-variant pb-1">:</span>
            <div className="flex flex-col">
              <span className="font-mono font-semibold text-3xl md:text-4xl text-on-surface leading-none">
                {String(countdown.minutes).padStart(2, '0')}
              </span>
              <span className="font-sans text-[10px] font-bold text-on-surface-variant mt-1">MINS</span>
            </div>
            <span className="font-mono text-2xl text-on-surface-variant pb-1 opacity-40">:</span>
            <div className="flex flex-col opacity-50">
              <span className="font-mono text-xl md:text-2xl text-on-surface leading-none">
                {String(countdown.seconds).padStart(2, '0')}
              </span>
              <span className="font-sans text-[10px] font-bold text-on-surface-variant mt-1">SEC</span>
            </div>
          </div>
          <div className="text-right text-[10px] text-on-surface-variant italic font-mono uppercase">
            Bahrain Int. Circuit
          </div>
        </div>

        {/* WEEKEND RADAR */}
        <div className="col-span-1 md:col-span-4 carbon-card rounded-lg p-5 flex flex-col justify-between h-48">
          <div className="flex items-center justify-between">
            <span className="font-mono text-xs font-bold tracking-wider text-on-surface-variant uppercase">
              WEEKEND RADAR
            </span>
            <span className="font-mono text-[10px] bg-emerald-500/10 text-emerald-500 px-1.5 py-0.5 rounded border border-emerald-500/20 uppercase font-bold animate-pulse">
              FP1 Live
            </span>
          </div>
          <div className="flex flex-col gap-2.5 my-auto">
            <div className="flex justify-between items-center text-xs">
              <span className="font-mono font-bold text-f1-red">FP1 (CRITICAL COMPOUND)</span>
              <span className="font-bold text-on-surface">LIVE NOW</span>
            </div>
            <div className="border-t border-white/5 my-1" />
            <div className="flex justify-between items-center text-xs opacity-60">
              <span className="font-mono font-medium text-on-surface">FP2 (AERO SIM)</span>
              <span className="font-mono">TODAY 18:00</span>
            </div>
            <div className="border-t border-white/5 my-1" />
            <div className="flex justify-between items-center text-xs opacity-40">
              <span className="font-mono font-medium text-on-surface">QUALIFYING</span>
              <span className="font-mono">SAT 15:00</span>
            </div>
          </div>
          <div className="text-[10px] text-on-surface-variant italic font-mono uppercase">
            REMAINING TRACK TIME: {(session.remainingTime / 60).toFixed(0)} MIN
          </div>
        </div>

        {/* LATEST INTEL */}
        <div className="col-span-1 md:col-span-4 carbon-card rounded-lg p-5 flex flex-col justify-between h-48 relative group cursor-pointer" onClick={() => onNavigate('analysis')}>
          <div className="absolute inset-0 bg-cover bg-center opacity-15 transition-opacity duration-300 group-hover:opacity-25" style={{ backgroundImage: "url('https://lh3.googleusercontent.com/aida-public/AB6AXuDZ2wAH9cZJjTBKgrg4oR9TWk8tG09XL2gIighNVnxdur5YQrdNfPq1wJm1a-gCrXk6U20ODVxQ9FKq6pk6ZUrnBFVzNtaASUHTxUmXZOtaVViS-A37nV7keVhLglpZ3Vt8-t9-qIKchVYQur0D388czJhr-nw81xm5ccs8fkc2atKSXwm1A09JcRH73hpltZ06IzZqMbv-ko5NE2OpLoLcnSmauZoKNbe7yYNw-sg2NJdGodTiHUzsjXAyQLBRlL2xWfCZds64bk0')" }}></div>
          
          <div className="flex items-center justify-between relative z-10">
            <span className="font-mono text-xs font-bold tracking-wider text-on-surface-variant uppercase">
              LATEST INTEL
            </span>
            <AlertOctagon size={14} className="text-f1-red animate-pulse" />
          </div>
          <div className="relative z-10 my-auto">
            <h3 className="font-sans font-extrabold text-[13px] text-on-surface line-clamp-1 group-hover:text-f1-red transition-colors">
              {intel[0]?.title || 'NEW UPGRADES DETECTED'}
            </h3>
            <p className="font-sans font-normal text-xs text-on-surface-variant mt-1.5 leading-snug line-clamp-2">
              {intel[0]?.content || 'Checking live telemetry feeds for Red Bull & Ferrari upgrades...'}
            </p>
          </div>
          <div className="relative z-10 flex justify-between items-center">
            <span className="font-mono text-[10px] text-f1-red group-hover:underline flex items-center gap-1">
              OPEN ENGINEER FEED <ChevronRight size={10} />
            </span>
            <span className="font-mono text-[10px] text-on-surface-variant/70 italic">
              RECEIVED {intel[0]?.timestamp || '15:24'}
            </span>
          </div>
        </div>

      </div>

      {/* Driver Standings Widget & Podium Widget */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
        
        {/* TOP CHAMPIONSHIP STANDINGS (DRIVER TOP 5) */}
        <div className="col-span-1 md:col-span-6 carbon-card rounded-lg p-5 flex flex-col justify-between min-h-[320px]">
          <div>
            <div className="flex items-center justify-between border-b border-white/5 pb-3">
              <div className="flex items-center gap-2">
                <TrendingUp size={14} className="text-on-surface-variant" />
                <span className="font-mono text-xs font-bold tracking-wider text-on-surface-variant uppercase">
                  CHAMPIONSHIP STANDINGS (TOP 5)
                </span>
              </div>
              <button 
                onClick={() => onNavigate('standings')}
                className="font-mono text-[11px] text-f1-red hover:underline uppercase font-bold"
              >
                Full Standings
              </button>
            </div>
            
            <div className="flex flex-col mt-2">
              {top5Drivers.map((driver, index) => (
                <div 
                  key={driver.id} 
                  className={`flex justify-between items-center py-2.5 px-2 rounded hover:bg-white/5 cursor-pointer transition-all ${selectedDriver?.id === driver.id ? 'bg-white/10 border-l-2 border-f1-red' : 'data-row'}`}
                  onClick={() => setSelectedDriver(driver)}
                >
                  <div className="flex items-center gap-3">
                    <span className="font-mono text-xs font-bold text-on-surface-variant w-4">
                      {index + 1}
                    </span>
                    <div className="w-1.5 h-4 rounded-sm" style={{ backgroundColor: driver.teamColor }} />
                    <div className="flex flex-col">
                      <span className="font-mono font-black text-sm tracking-tight text-on-surface-variant">
                        {driver.code} 
                        <span className="font-sans font-medium text-xs text-on-surface-variant ml-2 hidden sm:inline">
                          {driver.name}
                        </span>
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <span className="font-mono text-[10px] px-1.5 py-0.5 bg-white/5 rounded text-white/60">
                      #{driver.number}
                    </span>
                    <span className="font-mono font-bold text-xs text-on-surface">
                      {driver.points} PTS
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          <div className="text-[10px] text-on-surface-variant/60 font-mono mt-2">
            * POINTS REPRESENT LIVE CONSTRUCTOR ACCUMULATION FOR RECENT GP RESULTS.
          </div>
        </div>

        {/* LAST RACE PODIUM WIDGET */}
        <div className="col-span-1 md:col-span-6 carbon-card rounded-lg p-5 flex flex-col justify-between min-h-[320px]">
          <div>
            <div className="flex items-center justify-between border-b border-white/5 pb-3">
              <div className="flex items-center gap-2">
                <Award size={14} className="text-on-surface-variant" />
                <span className="font-mono text-xs font-bold tracking-wider text-on-surface-variant uppercase">
                  LAST RACE PODIUM (BAHRAIN GP)
                </span>
              </div>
              <span className="font-mono text-[10px] text-on-surface-variant uppercase">
                FIA Validated
              </span>
            </div>
            
            {/* 3D-Like Podium Bars */}
            <div className="flex items-end justify-center gap-3 mt-10 h-36">
              {/* P2: Charles Leclerc */}
              <div className="flex flex-col items-center w-1/3">
                <span className="font-sans font-black text-xs text-on-surface animate-bounce">LEC</span>
                <span className="text-[9px] text-on-surface-variant font-mono mb-1">Ferrari</span>
                <div className="w-full bg-surface-high border-t-4 border-f1-red flex flex-col items-center justify-between py-3 h-20 rounded-t-sm">
                  <span className="font-mono font-black text-2xl text-on-surface-variant">2</span>
                  <span className="text-[9px] font-mono text-on-surface-variant">47 PTS</span>
                </div>
              </div>

              {/* P1: Max Verstappen */}
              <div className="flex flex-col items-center w-1/3">
                <div className="flex items-center gap-0.5 text-f1-red animate-pulse mb-1">
                  <Flame size={12} fill="currentColor" />
                  <span className="font-sans font-black text-xs text-on-surface">VER</span>
                </div>
                <span className="text-[9px] text-f1-red font-mono mb-1">Red Bull</span>
                <div className="w-full bg-surface-highest border-t-4 border-cyan-400 flex flex-col items-center justify-between py-3 h-28 rounded-t-sm">
                  <span className="font-mono font-black text-3xl text-f1-red">1</span>
                  <span className="text-[9px] font-mono text-on-surface">51 PTS</span>
                </div>
              </div>

              {/* P3: Lando Norris */}
              <div className="flex flex-col items-center w-1/3">
                <span className="font-sans font-black text-xs text-on-surface">NOR</span>
                <span className="text-[9px] text-on-surface-variant font-mono mb-1">McLaren</span>
                <div className="w-full bg-surface-high border-t-4 border-orange-500 flex flex-col items-center justify-between py-3 h-16 rounded-t-sm">
                  <span className="font-mono font-black text-xl text-on-surface-variant">3</span>
                  <span className="text-[9px] font-mono text-on-surface-variant">42 PTS</span>
                </div>
              </div>
            </div>
          </div>

          <div className="flex justify-between items-center text-[10px] text-on-surface-variant bg-white/5 p-2 rounded mt-4">
            <span className="font-mono uppercase">Fastest Lap Unit: VER</span>
            <span className="font-mono text-f1-red font-bold">1:34.250</span>
          </div>
        </div>

      </div>

      {/* Engineer Intel Feed (Small list overlay) */}
      <div className="carbon-card rounded-lg p-5">
        <h2 className="font-mono text-xs font-bold tracking-wider text-on-surface-variant uppercase border-b border-white/5 pb-3">
          ENGINEER INTEL BULLETIN INDEX
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-3">
          {intel.slice(1).map((msg) => (
            <div key={msg.id} className={`flex gap-3 p-3 rounded border border-white/5 ${getIntensityStyle(msg.type)}`}>
              <div className="font-mono font-bold text-xs pt-1">{msg.timestamp}</div>
              <div>
                <h3 className="font-mono font-bold text-xs tracking-tight uppercase text-on-surface">
                  {msg.title}
                </h3>
                <p className="font-sans text-[11px] text-on-surface-variant mt-1.5 leading-snug">
                  {msg.content}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
}
