import { useState } from 'react';
import { Driver, IntelMessage } from '../types';
import { Wrench, FileCode, CheckCircle2, RefreshCcw, Cpu } from 'lucide-react';

interface AnalysisViewProps {
  drivers: Driver[];
  intel: IntelMessage[];
}

export default function AnalysisView({ drivers, intel }: AnalysisViewProps) {
  const [selectedLap, setSelectedLap] = useState<number>(12);
  const [activeDriverA, setActiveDriverA] = useState<string>('ver');
  const [activeDriverB, setActiveDriverB] = useState<string>('lec');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [diagnosticLog, setDiagnosticLog] = useState<string[]>([]);

  const driverA = drivers.find(d => d.id === activeDriverA) || drivers[0];
  const driverB = drivers.find(d => d.id === activeDriverB) || drivers[1];
  const latestIntel = intel[0];

  const handleRunAnalysis = () => {
    setIsAnalyzing(true);
    setDiagnosticLog([]);
    
    setTimeout(() => {
      setDiagnosticLog(prev => [
        ...prev,
        '📡 INITIALISING BEACON BEAMS AT 50HZ...',
        `🏎️ LOADED TELEMETRY CHASSIS MATRIX FOR: ${driverA.code} vs ${driverB.code}`,
        `⏱️ ANALYSING LAP DELTAS: LAP ${selectedLap} OUT-LAPS REGISTERED`,
        '📊 COMPUTING CORNERING DELTAS AT T1, T4, T8, & T10...',
        `🏁 RESULT: T1 Apex Delta is +0.045s in favour of ${driverA.code}`,
        `🏁 RESULT: T9-T10 Double Left Entry is +0.120s in favour of ${driverB.code} (Better mechanical traction)`,
        `🌡️ TYRE SLIP COEFFICIENT: ${driverA.code} S1 Compound is running 1.2°C warmer. Core degradation margin: nominal.`,
        '🔥 DIAGNOSTIC BOUNDARY CHECKS COMPLETE: 100% HEALTHY'
      ]);
      setIsAnalyzing(false);
    }, 1200);
  };

  return (
    <div className="flex flex-col gap-5 animate-fade-in">
      
      {/* ANTIGRAVITY REFERENCE & IMPORT CONSOLE HUD */}
      <div className="p-5 bg-f1-red/10 border border-f1-red/30 rounded-lg flex flex-col gap-3">
        <div className="flex items-start gap-3">
          <div className="p-2.5 bg-f1-red text-white rounded">
            <Cpu size={18} />
          </div>
          <div>
            <h2 className="font-sans font-black text-sm text-on-surface uppercase tracking-wide">
              HOW TO IMPORT EXISTING FILES FROM ANTIGRAVITY HERE
            </h2>
            <p className="font-sans text-xs text-on-surface-variant mt-1.5 leading-relaxed">
              To persist, build on, or keep consistent design architectures from your prior files, you can upload components directly into this browser instance. Here is the operational blueprint:
            </p>
          </div>
        </div>

        {/* Dynamic checklist step layout */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5 mt-3">
          {/* Step 1 */}
          <div className="bg-black/35 p-3.5 rounded border border-white/5 flex flex-col justify-between">
            <div>
              <div className="font-mono text-[9px] text-f1-red font-bold uppercase">STEP 1: UPLOAD FILES IN INTERFACE</div>
              <p className="font-sans text-[11px] text-on-surface-variant mt-2 leading-snug">
                Drag and drop your <code className="text-white bg-white/5 px-1 py-0.5 rounded">.tsx</code>, <code className="text-white bg-white/5 px-1 py-0.5 rounded">.css</code>, or state files anywhere into the <strong className="text-white">Left Panel File Explorer</strong> in Google AI Studio, or attach them in your chat prompt.
              </p>
            </div>
            <div className="mt-4 flex items-center text-[10px] text-emerald-400 font-mono gap-1">
              <CheckCircle2 size={11} /> READY FOR INPUTS
            </div>
          </div>

          {/* Step 2 */}
          <div className="bg-black/35 p-3.5 rounded border border-white/5 flex flex-col justify-between">
            <div>
              <div className="font-mono text-[9px] text-f1-red font-bold uppercase">STEP 2: MODULAR ARCHITECTURE ALIGNMENT</div>
              <p className="font-sans text-[11px] text-on-surface-variant mt-2 leading-snug">
                We have pre-structured this codebase to be modular. Put your custom widgets in <code className="text-white bg-white/5 px-1">/src/components/</code> and import them inside <code className="text-white bg-white/5 px-1">/src/App.tsx</code> to keep styles consistent.
              </p>
            </div>
            <div className="mt-4 flex items-center text-[10px] text-on-surface-variant/80 font-mono gap-1">
              <FileCode size={11} strokeWidth={2.5} /> COMPATIBLE
            </div>
          </div>

          {/* Step 3 */}
          <div className="bg-black/35 p-3.5 rounded border border-white/5 flex flex-col justify-between">
            <div>
              <div className="font-mono text-[9px] text-f1-red font-bold uppercase">STEP 3: CONFIGURATION MERGING</div>
              <p className="font-sans text-[11px] text-on-surface-variant mt-2 leading-snug">
                To keep tailwind-settings, refer to our customized theme tokens in <code className="text-white bg-white/5 px-1">/src/index.css</code>. No need for complex config configurations—it runs directly over Tailwind v4!
              </p>
            </div>
            <div className="mt-4 flex items-center text-[10px] text-f1-red font-mono gap-1 uppercase font-bold">
              <Wrench size={11} strokeWidth={2.5} /> FULLY EDITABLE VIA AGENT
            </div>
          </div>
        </div>
      </div>

      {latestIntel && (
        <div className="carbon-card rounded-lg px-4 py-3 flex items-center gap-3 border-l-4 border-l-f1-red">
          <span className="font-mono text-[10px] text-f1-red font-bold">{latestIntel.timestamp}</span>
          <span className="font-mono text-[10px] text-on-surface-variant uppercase tracking-wider">LATEST INTEL</span>
          <span className="font-sans text-xs text-on-surface font-bold">{latestIntel.title}</span>
          <span className="font-sans text-[11px] text-on-surface-variant truncate">{latestIntel.content}</span>
        </div>
      )}

      {/* Dynamic Telemetry Delta Audit Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        
        {/* Left Column: Log Selection Parameter Block */}
        <div className="lg:col-span-4 flex flex-col gap-4">
          <div className="carbon-card rounded-lg p-5">
            <h3 className="font-sans font-black text-sm text-on-surface border-b border-white/5 pb-2 uppercase tracking-wide">
              DIAGNOSTIC CONTROLLER
            </h3>
            
            <div className="flex flex-col gap-4 mt-4">
              {/* Select Parameter LAP */}
              <div className="flex flex-col gap-1.5">
                <label className="font-mono text-[10px] text-on-surface-variant uppercase">TARGET EVALUATION LAP</label>
                <div className="flex items-center gap-2">
                  <input
                    type="range"
                    min="1"
                    max="57"
                    value={selectedLap}
                    onChange={(e) => setSelectedLap(Number(e.target.value))}
                    className="w-full accent-f1-red bg-white/10"
                  />
                  <span className="font-mono text-xs font-bold text-on-surface w-12 text-right">LAP {selectedLap}</span>
                </div>
              </div>

              {/* Driver A Select */}
              <div className="flex flex-col gap-1.5">
                <label className="font-mono text-[10px] text-on-surface-variant uppercase">DRIVER CODE ALPHA</label>
                <select
                  value={activeDriverA}
                  onChange={(e) => setActiveDriverA(e.target.value)}
                  className="bg-black/45 border border-white/10 rounded px-3 py-2 font-mono text-xs text-white uppercase focus:border-f1-red focus:outline-none"
                >
                  {drivers.map(d => (
                    <option key={d.id} value={d.id}>{d.code} - {d.name}</option>
                  ))}
                </select>
              </div>

              {/* Driver B Select */}
              <div className="flex flex-col gap-1.5">
                <label className="font-mono text-[10px] text-on-surface-variant uppercase">DRIVER CODE BETA</label>
                <select
                  value={activeDriverB}
                  onChange={(e) => setActiveDriverB(e.target.value)}
                  className="bg-black/45 border border-white/10 rounded px-3 py-2 font-mono text-xs text-white uppercase focus:border-f1-red focus:outline-none"
                >
                  {drivers.filter(d => d.id !== activeDriverA).map(d => (
                    <option key={d.id} value={d.id}>{d.code} - {d.name}</option>
                  ))}
                </select>
              </div>

              {/* Audit run button */}
              <button
                onClick={handleRunAnalysis}
                disabled={isAnalyzing}
                className="w-full bg-f1-red hover:bg-red-700 text-white font-mono font-bold text-xs uppercase py-3 rounded tracking-wider cursor-pointer mt-2 flex items-center justify-center gap-2 transition-colors disabled:opacity-50"
              >
                {isAnalyzing ? (
                  <>
                    <RefreshCcw size={12} className="animate-spin" />
                    AUDITING DATA CORRIDOR...
                  </>
                ) : (
                  <>
                    <Wrench size={12} />
                    SIMULATE BOUNDARY DELTAS
                  </>
                )}
              </button>

            </div>
          </div>
        </div>

        {/* Right Column: Console Log Prints */}
        <div className="lg:col-span-8 carbon-card rounded-lg p-5 flex flex-col justify-between min-h-[300px]">
          <div>
            <h3 className="font-sans font-black text-sm text-on-surface border-b border-white/5 pb-2 uppercase tracking-wide">
              ENGINE PANEL CONSOLE PRINT-OUTS
            </h3>
            
            <div className="mt-4 font-mono text-xs text-white/90 bg-black/40 border border-white/5 rounded p-4 flex flex-col gap-2 min-h-[180px] h-64 overflow-y-auto">
              {diagnosticLog.length === 0 ? (
                <div className="m-auto text-center text-on-surface-variant italic">
                  Chassis delta registers are clear. Click 'SIMULATE BOUNDARY DELTAS' to generate audit traces.
                </div>
              ) : (
                diagnosticLog.map((log, index) => (
                  <div key={index} className="leading-snug">
                    <span className="text-f1-red mr-2">&gt;&gt;</span>
                    {log}
                  </div>
                ))
              )}
            </div>
          </div>

          <div className="flex justify-between items-center text-[10px] font-mono text-on-surface-variant bg-white/5 p-2 rounded mt-3">
            <span>COMPUTATION COST: 0.1ms</span>
            <span>TELEMETRY BEACON RATIO: 50HZ OK</span>
          </div>
        </div>

      </div>

    </div>
  );
}
