import { useState } from 'react';
import { Driver } from '../types';
import { SAKHIR_VECTOR_POINTS } from '../data';
import { Map, Layers, Info } from 'lucide-react';

interface TrackMapViewProps {
  drivers: Driver[];
  selectedDriver: Driver | null;
  setSelectedDriver: (driver: Driver | null) => void;
}

export default function TrackMapView({
  drivers,
  selectedDriver,
  setSelectedDriver,
}: TrackMapViewProps) {
  const [trackStyle, setTrackStyle] = useState<'carbon' | 'thermal' | 'sectors'>('carbon');
  const [showTurnLabels, setShowTurnLabels] = useState(true);

  // Linear Interpolation helper to get coordinate on the track
  const getDriverCoordinates = (progress: number) => {
    const points = SAKHIR_VECTOR_POINTS;
    const numSegments = points.length - 1;
    
    // Safely clamp progress 0 to 1
    const clampedProgress = Math.max(0, Math.min(1, progress));
    const rawIndex = clampedProgress * numSegments;
    const segmentIndex = Math.floor(rawIndex);
    const localT = rawIndex - segmentIndex;
    
    const p1 = points[segmentIndex];
    const p2 = points[segmentIndex + 1] || points[0];
    
    const x = p1.x + (p2.x - p1.x) * localT;
    const y = p1.y + (p2.y - p1.y) * localT;
    
    return { x, y };
  };

  // Build the SVG path string from points
  const buildSvgPath = () => {
    const points = SAKHIR_VECTOR_POINTS;
    return points.reduce((acc, p, i) => {
      if (i === 0) return `M ${p.x} ${p.y}`;
      return `${acc} L ${p.x} ${p.y}`;
    }, '') + ' Z';
  };

  // Segmented path colors based on Track style
  const getTrackStrokeColor = () => {
    switch (trackStyle) {
      case 'thermal': return 'stroke-amber-500/70';
      case 'sectors': return 'stroke-sky-500/80';
      default: return 'stroke-f1-red';
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 animate-fade-in">
      
      {/* Dynamic Map Display Panel (Grid Left) */}
      <div className="col-span-1 lg:col-span-8 carbon-card rounded-lg p-5 flex flex-col justify-between">
        
        {/* Header control rails */}
        <div className="flex justify-between items-center border-b border-white/5 pb-3">
          <div className="flex items-center gap-2">
            <Map size={15} className="text-on-surface-variant" />
            <span className="font-mono text-xs font-bold tracking-wider text-on-surface-variant uppercase">
              LIVE SAKHIR TRACK TELEMETRY OVERLAY
            </span>
          </div>
          
          <div className="flex gap-2">
            {/* Toggle styles */}
            <button
              onClick={() => setTrackStyle(prev => prev === 'carbon' ? 'thermal' : prev === 'thermal' ? 'sectors' : 'carbon')}
              className="flex items-center gap-1 bg-white/5 hover:bg-white/10 text-on-surface-variant px-2.5 py-1.5 rounded text-[10px] font-mono font-bold uppercase border border-white/10 transition-colors"
            >
              <Layers size={11} />
              STYLE: {trackStyle}
            </button>
            <button
              onClick={() => setShowTurnLabels(!showTurnLabels)}
              className={`flex items-center gap-1 px-2.5 py-1.5 rounded text-[10px] font-mono font-bold uppercase border transition-colors ${showTurnLabels ? 'bg-f1-red/10 border-f1-red/25 text-f1-red' : 'bg-white/5 border-white/10 text-on-surface-variant hover:bg-white/10'}`}
            >
              <Info size={11} />
              TURNS
            </button>
          </div>
        </div>

        {/* Large SVG Map Container */}
        <div className="flex-1 flex items-center justify-center min-h-[360px] relative p-4 max-h-[500px]">
          
          {/* Legend corner indicators */}
          <div className="absolute top-4 left-4 font-mono text-[10px] text-on-surface-variant bg-black/40 p-2.5 border border-white/5 rounded flex flex-col gap-1.5 z-10 backdrop-blur-sm">
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-1.5 bg-f1-red rounded-sm" />
              <span>DRS ZONE A (MAIN STRAIGHT)</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-1.5 bg-cyan-400 rounded-sm" />
              <span>DRS ZONE B (BACK CURVE)</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full border border-f1-red animate-ping" />
              <span>SECTOR TIME TRAPS</span>
            </div>
          </div>

          <svg
            viewBox="50 100 800 750"
            className="w-full h-full max-w-[500px] max-h-[440px]"
          >
            {/* Ambient grid background matching tactical race control radar screens */}
            <defs>
              <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                <path d="M 40 0 L 0 0 0 40" fill="none" stroke="rgba(255, 255, 255, 0.02)" strokeWidth="1" />
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill="none" />

            {/* Gray backing track path trace (Roadway boundary footprint) */}
            <path
              d={buildSvgPath()}
              fill="none"
              stroke="#2a2a2a"
              strokeWidth="22"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="opacity-40"
            />

            {/* Inner track path trace */}
            <path
              d={buildSvgPath()}
              fill="none"
              stroke="#131313"
              strokeWidth="14"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            
            {/* The active racing line colored by selected style */}
            <path
              d={buildSvgPath()}
              fill="none"
              strokeWidth="2.5"
              strokeLinecap="round"
              strokeLinejoin="round"
              className={`transition-all duration-300 ${getTrackStrokeColor()}`}
              strokeDasharray={trackStyle === 'sectors' ? '12, 12' : undefined}
            />

            {/* START / FINISH LINE */}
            <line
              x1="120" y1="730"
              x2="120" y2="770"
              stroke="#ffffff"
              strokeWidth="3.5"
              strokeDasharray="2, 2"
            />
            <text x="96" y="805" className="fill-white/40 font-mono text-[9px] font-bold tracking-widest uppercase">
              START / FINISH
            </text>

            {/* Render Turn Badges along the path */}
            {showTurnLabels && SAKHIR_VECTOR_POINTS.map((pt, i) => {
              if (!pt.name) return null;
              return (
                <g key={i}>
                  <circle cx={pt.x} cy={pt.y} r="10" className="fill-surface-highest stroke-white/10 stroke-1" />
                  <text 
                    x={pt.x} 
                    y={pt.y + 3.5} 
                    className="fill-on-surface-variant font-sans text-[8px] font-black text-center"
                    textAnchor="middle"
                  >
                    {pt.name}
                  </text>
                </g>
              );
            })}

            {/* Render Driver dots on the track path in real-time */}
            {drivers.map(driver => {
              const pos = getDriverCoordinates(driver.trackProgress);
              const isDriverSelected = selectedDriver?.id === driver.id;
              
              return (
                <g
                  key={driver.id}
                  className="cursor-pointer"
                  onClick={(e) => {
                    e.stopPropagation();
                    setSelectedDriver(driver);
                  }}
                >
                  {/* Selected glowing beacon */}
                  {isDriverSelected && (
                    <circle
                      cx={pos.x}
                      cy={pos.y}
                      r="18"
                      className="fill-none stroke-f1-red animate-pulse"
                      strokeWidth="2"
                    />
                  )}

                  {/* Outer circle matched to F1 Team Color */}
                  <circle
                    cx={pos.x}
                    cy={pos.y}
                    r="9"
                    fill={driver.teamColor}
                    className="stroke-background stroke-2 transition-all duration-150"
                  />

                  {/* Text Label on map: Driver Code inside circle */}
                  <text
                    x={pos.x}
                    y={pos.y + 2.5}
                    className="fill-black font-sans font-black text-[7px]"
                    textAnchor="middle"
                  >
                    {driver.code.substring(0, 2)}
                  </text>

                  {/* High fidelity tag labeling the driver on map */}
                  <g transform={`translate(${pos.x + 12}, ${pos.y - 12})`}>
                    <rect
                      width="26"
                      height="12"
                      rx="2"
                      className="fill-black/85 stroke-white/10 stroke-[0.5px]"
                    />
                    <text
                      x="13"
                      y="9"
                      className="fill-white font-mono text-[7px] font-bold"
                      textAnchor="middle"
                    >
                      {driver.code}
                    </text>
                  </g>
                </g>
              );
            })}
          </svg>

        </div>

        {/* Informational telemetry footer */}
        <div className="flex justify-between items-center text-[10px] font-mono text-on-surface-variant bg-white/5 p-2 rounded">
          <span className="uppercase">Total Map Length: 5.412 KM</span>
          <span className="text-f1-red font-black uppercase">LIVE COORD CAPTURE FEED ACTIVE</span>
        </div>

      </div>

      {/* Driver Telemetry details bar (Grid Right) */}
      <div className="col-span-1 lg:col-span-4 flex flex-col gap-4">
        
        {/* Telemetry quick look card */}
        <div className="carbon-card rounded-lg p-5 flex-1 flex flex-col justify-between min-h-[300px]">
          <div>
            <h2 className="font-mono text-xs font-bold tracking-wider text-on-surface-variant border-b border-white/5 pb-2 uppercase">
              SELECTED CAR STATUS
            </h2>
            
            {selectedDriver ? (
              <div className="mt-4 flex flex-col gap-4">
                {/* Driver basic badge */}
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded bg-white/5 flex items-center justify-center font-sans font-black text-lg border border-white/10" style={{ color: selectedDriver.teamColor }}>
                    #{selectedDriver.number}
                  </div>
                  <div>
                    <h3 className="font-sans font-extrabold text-sm text-on-surface">
                      {selectedDriver.name}
                    </h3>
                    <p className="font-mono text-xs text-on-surface-variant uppercase">
                      {selectedDriver.team}
                    </p>
                  </div>
                </div>

                {/* Micro telemetry bars */}
                <div className="flex flex-col gap-3 mt-4">
                  {/* Speed km/h */}
                  <div className="flex flex-col">
                    <div className="flex justify-between text-xs font-mono">
                      <span className="text-on-surface-variant">SPEED</span>
                      <span className="text-on-surface font-bold">{selectedDriver.speed} KM/H</span>
                    </div>
                    <div className="w-full bg-white/5 h-1.5 rounded overflow-hidden mt-1">
                      <div className="bg-f1-red h-full transition-all duration-150" style={{ width: `${(selectedDriver.speed / 330) * 100}%` }} />
                    </div>
                  </div>

                  {/* Throttle & Brake indicators */}
                  <div className="grid grid-cols-2 gap-3">
                    <div className="flex flex-col">
                      <div className="flex justify-between text-[10px] font-mono">
                        <span className="text-on-surface-variant">THROTTLE</span>
                        <span className="text-emerald-400 font-bold">{selectedDriver.throttle}%</span>
                      </div>
                      <div className="w-full bg-white/5 h-1.5 rounded overflow-hidden mt-1">
                        <div className="bg-emerald-500 h-full transition-all duration-150" style={{ width: `${selectedDriver.throttle}%` }} />
                      </div>
                    </div>
                    <div className="flex flex-col">
                      <div className="flex justify-between text-[10px] font-mono">
                        <span className="text-on-surface-variant">BRAKE</span>
                        <span className="text-red-400 font-bold">{selectedDriver.brake}%</span>
                      </div>
                      <div className="w-full bg-white/5 h-1.5 rounded overflow-hidden mt-1">
                        <div className="bg-red-500 h-full transition-all duration-150" style={{ width: `${selectedDriver.brake}%` }} />
                      </div>
                    </div>
                  </div>

                  {/* RPM & Gear */}
                  <div className="flex justify-between items-center text-xs font-mono bg-black/35 p-2 rounded">
                    <div>
                      <div className="text-[10px] text-on-surface-variant uppercase">Engine RPM</div>
                      <div className="text-sm font-bold text-on-surface mt-0.5">{selectedDriver.rpm.toLocaleString()}</div>
                    </div>
                    <div>
                      <div className="text-[10px] text-on-surface-variant uppercase">Gear</div>
                      <div className="text-sm font-black text-f1-red text-right mt-0.5">{selectedDriver.gear === 0 ? 'N' : selectedDriver.gear}</div>
                    </div>
                  </div>

                  {/* DRS State */}
                  <div className={`p-2 rounded text-center text-[10px] font-mono font-bold tracking-widest ${selectedDriver.drs ? 'bg-emerald-500/10 border border-emerald-500/25 text-emerald-400' : 'bg-white/5 border border-white/5 text-white/30'}`}>
                    {selectedDriver.drs ? 'DRS ENABLED (WING OPEN)' : 'DRS DISABLED'}
                  </div>

                </div>

              </div>
            ) : (
              <div className="mt-12 text-center text-xs text-on-surface-variant italic">
                Click on any driver bubble or track segment to open telemetry reports.
              </div>
            )}
          </div>

          <div className="text-[9px] text-on-surface-variant/75 font-mono italic leading-relaxed border-t border-white/5 pt-3 mt-4">
            * Coordinates extracted via FIA loop beacons placed at 50M intervals.
          </div>
        </div>

      </div>

    </div>
  );
}
