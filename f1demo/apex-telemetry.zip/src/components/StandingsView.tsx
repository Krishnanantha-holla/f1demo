import { useState } from 'react';
import { Driver } from '../types';
import { Award, Trophy, Landmark, Star } from 'lucide-react';

interface StandingsViewProps {
  drivers: Driver[];
}

export default function StandingsView({ drivers }: StandingsViewProps) {
  const [standingsTab, setStandingsTab] = useState<'drivers' | 'constructors'>('drivers');

  // Sort drivers by Championship points total
  const sortedDrivers = [...drivers].sort((a, b) => b.points - a.points);

  // Group construct points dynamically
  const constructorsData = [
    { name: 'Red Bull Racing', points: 98, wins: 2, podiums: 3, primaryColor: '#3671C6' },
    { name: 'Ferrari', points: 87, wins: 0, podiums: 3, primaryColor: '#E10600' },
    { name: 'McLaren', points: 72, wins: 1, podiums: 2, primaryColor: '#FF8700' },
    { name: 'Mercedes-AMG', points: 47, wins: 0, podiums: 1, primaryColor: '#27F4D2' },
    { name: 'Aston Martin F1', points: 26, wins: 0, podiums: 0, primaryColor: '#229971' },
    { name: 'Williams Racing', points: 8, wins: 0, podiums: 0, primaryColor: '#37BEDD' },
    { name: 'Alpine F1 Team', points: 4, wins: 0, podiums: 0, primaryColor: '#FF87CD' },
  ].sort((a, b) => b.points - a.points);

  const maxDriverPoints = sortedDrivers[0]?.points || 1;
  const maxConstructPoints = constructorsData[0]?.points || 1;

  return (
    <div className="flex flex-col gap-4 animate-fade-in">
      
      {/* Category Tabs */}
      <div className="flex justify-between items-center border-b border-white/5 pb-2">
        <div className="flex gap-2">
          <button
            onClick={() => setStandingsTab('drivers')}
            className={`flex items-center gap-1.5 px-4 py-2 font-mono text-xs font-bold uppercase tracking-wider rounded transition-all ${standingsTab === 'drivers' ? 'bg-f1-red text-white' : 'bg-white/5 hover:bg-white/10 text-on-surface-variant'}`}
          >
            <Trophy size={13} fill="currentColor" />
            WORLD DRIVER CHAMPIONSHIP
          </button>
          
          <button
            onClick={() => setStandingsTab('constructors')}
            className={`flex items-center gap-1.5 px-4 py-2 font-mono text-xs font-bold uppercase tracking-wider rounded transition-all ${standingsTab === 'constructors' ? 'bg-f1-red text-white' : 'bg-white/5 hover:bg-white/10 text-on-surface-variant'}`}
          >
            <Landmark size={13} />
            WORLD CONSTRUCTORS CHAMPIONSHIP
          </button>
        </div>
        
        <span className="text-[10px] text-on-surface-variant font-mono uppercase bg-white/5 border border-white/5 px-2 py-1 rounded">
          ROUND 3 UPDATED
        </span>
      </div>

      {standingsTab === 'drivers' ? (
        /* Driver Standings */
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          {/* Main List Table */}
          <div className="lg:col-span-8 carbon-card rounded-lg overflow-x-auto">
            <table className="w-full text-left font-mono border-collapse min-w-[500px]">
              <thead>
                <tr className="bg-surface-container text-[10px] font-black tracking-wider text-on-surface-variant border-b border-white/10 uppercase">
                  <th className="py-3 px-4 w-12 text-center">POS</th>
                  <th className="py-3 px-2 w-10">NO</th>
                  <th className="py-3 px-3">DRIVER / TEAM</th>
                  <th className="py-3 px-4 w-36">CHAMPIONSHIP BAR</th>
                  <th className="py-3 px-4 text-center">WINS</th>
                  <th className="py-3 px-4 text-center">PODIUMS</th>
                  <th className="py-3 px-4 text-right">POINTS</th>
                </tr>
              </thead>
              <tbody>
                {sortedDrivers.map((driver, i) => {
                  const wins = driver.currentPosition === 1 ? 2 : driver.currentPosition === 3 ? 1 : 0;
                  const podiums = driver.currentPosition <= 3 ? 3 : driver.currentPosition === 4 ? 2 : 1;
                  return (
                    <tr key={driver.id} className="border-b border-white/5 text-xs text-on-surface/90 hover:bg-white/5 transition-all">
                      <td className="py-3 text-center font-bold font-sans italic text-f1-red text-sm">
                        {i + 1}
                      </td>
                      <td className="py-3 px-2 font-bold text-[11px] text-white/40">
                        {driver.number}
                      </td>
                      <td className="py-3 px-3 uppercase">
                        <div className="flex items-center gap-3.5">
                          <div className="w-1.5 h-4 rounded-sm" style={{ backgroundColor: driver.teamColor }} />
                          <div className="flex flex-col">
                            <span className="font-sans font-black text-sm text-on-surface tracking-tight">
                              {driver.code} <span className="font-normal font-mono text-xs text-on-surface-variant font-normal tracking-wide lowercase italic ml-1.5 hidden md:inline">{driver.name}</span>
                            </span>
                            <span className="text-[9px] text-on-surface-variant/70 font-mono tracking-wider">{driver.team}</span>
                          </div>
                        </div>
                      </td>
                      {/* Points Bar */}
                      <td className="py-3 px-4">
                        <div className="w-full bg-white/5 h-2 rounded mt-1 overflow-hidden">
                          <div 
                            className="h-full rounded-sm transition-all duration-500" 
                            style={{ 
                              width: `${(driver.points / maxDriverPoints) * 100}%`,
                              backgroundColor: driver.teamColor
                            }} 
                          />
                        </div>
                      </td>
                      <td className="py-3 px-4 text-center text-sm font-semibold text-white/50">
                        {wins > 0 ? (
                          <span className="text-yellow-500 flex items-center justify-center gap-0.5 font-bold">
                            <Star size={11} fill="currentColor" /> {wins}
                          </span>
                        ) : '-'}
                      </td>
                      <td className="py-3 px-4 text-center text-sm font-bold text-on-surface-variant">
                        {podiums}
                      </td>
                      <td className="py-3 px-4 text-right pr-6 font-black text-[13px] text-on-surface">
                        {driver.points} PTS
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Quick Championship Intel Card */}
          <div className="lg:col-span-4 flex flex-col gap-4">
            <div className="carbon-card rounded-lg p-5">
              <h3 className="font-sans font-black text-sm text-on-surface border-b border-white/5 pb-2 uppercase tracking-wide">
                FIA CHAMPIONSHIP INSIGHT
              </h3>
              <p className="font-sans text-xs text-on-surface-variant mt-3 leading-relaxed">
                With {sortedDrivers[0]?.name} claiming two victories in early proceedings, the Red Bull Racing stable holds an early 11-point lead. 
              </p>
              <div className="mt-4 flex flex-col gap-3 font-mono text-xs">
                <div className="flex justify-between bg-white/5 p-2 rounded">
                  <span className="text-on-surface-variant">Current Lead Margin</span>
                  <span className="text-f1-red font-bold">4 PTS (VER OVER LEC)</span>
                </div>
                <div className="flex justify-between bg-white/5 p-2 rounded">
                  <span className="text-on-surface-variant">Total Laps Raced</span>
                  <span className="text-on-surface">171 Laps</span>
                </div>
                <div className="flex justify-between bg-white/5 p-2 rounded">
                  <span className="text-on-surface-variant">Fastest Pit Stop Season</span>
                  <span className="text-green-400 font-bold">McLaren (1.80S)</span>
                </div>
              </div>
            </div>
            
            <div className="carbon-card rounded-lg p-5 flex-1 flex flex-col justify-between">
              <div className="flex items-center gap-2">
                <Award size={15} className="text-yellow-500 animate-spin" />
                <span className="font-sans font-bold text-xs text-on-surface-variant uppercase">Title Battle Projection</span>
              </div>
              <div className="my-auto mt-4">
                <div className="text-[11px] font-mono text-on-surface-variant">STATISTICAL DOMINANCE FACTOR</div>
                <div className="text-lg font-black text-on-surface uppercase mt-1">VERSTAPPEN 59.5%</div>
                <div className="w-full bg-white/5 h-1.5 rounded mt-2 overflow-hidden">
                  <div className="bg-f1-red h-full" style={{ width: '59.5%' }} />
                </div>
              </div>
              <div className="text-[9px] text-white/30 font-mono mt-3 uppercase italic">
                * Based on neural simulation of Sakhir & Jeddah race sector trace profiles.
              </div>
            </div>
          </div>
        </div>
      ) : (
        /* Constructors Standings */
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          {/* Constructors Table */}
          <div className="lg:col-span-8 carbon-card rounded-lg overflow-x-auto">
            <table className="w-full text-left font-mono border-collapse min-w-[500px]">
              <thead>
                <tr className="bg-surface-container text-[10px] font-black text-on-surface-variant border-b border-white/10 uppercase tracking-wider">
                  <th className="py-3 px-4 w-12 text-center">POS</th>
                  <th className="py-3 px-3">TEAM CONSTRUCTOR</th>
                  <th className="py-3 px-4 w-36">CHAMPIONSHIP BAR</th>
                  <th className="py-3 px-4 text-center">WINS</th>
                  <th className="py-3 px-4 text-center">PODIUMS</th>
                  <th className="py-3 px-4 text-right">POINTS</th>
                </tr>
              </thead>
              <tbody>
                {constructorsData.map((team, index) => (
                  <tr key={team.name} className="border-b border-white/5 text-xs text-on-surface/90 hover:bg-white/5 transition-all">
                    <td className="py-3 text-center font-bold font-sans italic text-f1-red text-sm">
                      {index + 1}
                    </td>
                    <td className="py-3 px-3 uppercase">
                      <div className="flex items-center gap-3.5">
                        <div className="w-1.5 h-4 rounded-sm" style={{ backgroundColor: team.primaryColor }} />
                        <span className="font-sans font-extrabold text-sm text-on-surface tracking-tight">{team.name}</span>
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <div className="w-full bg-white/5 h-2 rounded mt-1 overflow-hidden">
                        <div 
                          className="h-full rounded-sm transition-all duration-500" 
                          style={{ 
                            width: `${(team.points / maxConstructPoints) * 100}%`,
                            backgroundColor: team.primaryColor
                          }} 
                        />
                      </div>
                    </td>
                    <td className="py-3 px-4 text-center text-sm font-semibold">
                      {team.wins > 0 ? (
                        <span className="text-yellow-500 flex items-center justify-center gap-0.5 font-bold">
                          <Star size={11} fill="currentColor" /> {team.wins}
                        </span>
                      ) : '-'}
                    </td>
                    <td className="py-3 px-4 text-center text-sm font-bold text-on-surface-variant">
                      {team.podiums}
                    </td>
                    <td className="py-3 px-4 text-right pr-6 font-black text-[13px] text-on-surface">
                      {team.points} PTS
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Constructor Stats Card */}
          <div className="lg:col-span-4 flex flex-col gap-4">
            <div className="carbon-card rounded-lg p-5">
              <h3 className="font-sans font-black text-sm text-on-surface border-b border-white/5 pb-2 uppercase tracking-wide">
                TEAM DEVELOPMENT CORRIDOR
              </h3>
              <p className="font-sans text-xs text-on-surface-variant mt-3 leading-relaxed">
                Ferrari's chassis has surpassed Red Bull on low-speed corner entries, but Red Bull retains a 0.22s aerodynamic boundary down the main straightaways. 
              </p>
              
              <div className="mt-4 flex flex-col gap-4 font-mono text-[10px]">
                <div>
                  <div className="flex justify-between uppercase">
                    <span>Ferrari Power Unit Efficiency</span>
                    <span className="text-f1-red font-bold">96.8%</span>
                  </div>
                  <div className="w-full bg-white/5 h-1.5 rounded mt-2 overflow-hidden">
                    <div className="bg-red-600 h-full" style={{ width: '96.8%' }} />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between uppercase">
                    <span>Red Bull Downforce Coefficient</span>
                    <span className="text-blue-400 font-bold">98.1%</span>
                  </div>
                  <div className="w-full bg-white/5 h-1.5 rounded mt-2 overflow-hidden">
                    <div className="bg-blue-500 h-full" style={{ width: '98.1%' }} />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between uppercase">
                    <span>McLaren High-Speed Cornering Stability</span>
                    <span className="text-orange-400 font-bold">94.2%</span>
                  </div>
                  <div className="w-full bg-white/5 h-1.5 rounded mt-2 overflow-hidden">
                    <div className="bg-orange-500 h-full" style={{ width: '94.2%' }} />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
