import { Driver, SessionInfo } from '../types';
import { Play, Pause, RotateCcw } from 'lucide-react';

interface LiveTimingViewProps {
  drivers: Driver[];
  session: SessionInfo;
  selectedDriver: Driver | null;
  setSelectedDriver: (driver: Driver | null) => void;
  isSimulating: boolean;
  setIsSimulating: (sim: boolean) => void;
  onResetSim: () => void;
}

export default function LiveTimingView({
  drivers,
  session,
  selectedDriver,
  setSelectedDriver,
  isSimulating,
  setIsSimulating,
  onResetSim,
}: LiveTimingViewProps) {
  // Sort drivers by position (1 to 10)
  const sortedDrivers = [...drivers].sort((a, b) => a.currentPosition - b.currentPosition);

  // Helper to color tyre compound standard F1 colors
  const getTyreStyle = (compound: 'S' | 'M' | 'H' | 'I' | 'W') => {
    switch (compound) {
      case 'S':
        return {
          bg: 'bg-red-600/10 border-red-500/45 text-red-500',
          dot: 'bg-red-500',
          label: 'SOFT',
        };
      case 'M':
        return {
          bg: 'bg-amber-500/10 border-amber-500/45 text-amber-500',
          dot: 'bg-amber-500',
          label: 'MEDIUM',
        };
      case 'H':
        return {
          bg: 'bg-white/10 border-white/45 text-white',
          dot: 'bg-white',
          label: 'HARD',
        };
      case 'I':
        return {
          bg: 'bg-emerald-500/10 border-emerald-400/45 text-emerald-400',
          dot: 'bg-emerald-400',
          label: 'INTER',
        };
      case 'W':
        return {
          bg: 'bg-blue-600/10 border-blue-500/45 text-blue-500',
          dot: 'bg-blue-500',
          label: 'WET',
        };
    }
  };

  const getSectorStyle = (state: 'best' | 'personal-best' | 'normal') => {
    switch (state) {
      case 'best':
        return 'text-purple-400 font-bold bg-purple-950/20 px-1 rounded border border-purple-500/15'; // Purple for overall session best
      case 'personal-best':
        return 'text-green-400 font-bold bg-green-950/20 px-1 rounded border border-green-500/15'; // Green for personal best
      default:
        return 'text-on-surface-variant font-medium';
    }
  };

  return (
    <div className="flex flex-col gap-4 animate-fade-in">
      
      {/* Control panel & summary stats */}
      <div className="flex flex-col sm:flex-row gap-3 justify-between items-start sm:items-center bg-surface-container p-4 rounded-lg border border-white/5">
        <div className="flex items-center gap-3">
          <button
            onClick={() => setIsSimulating(!isSimulating)}
            className={`flex items-center gap-2 px-4 py-2 font-mono font-bold text-xs rounded uppercase tracking-wider transition-colors duration-150 ${isSimulating ? 'bg-amber-600 text-white hover:bg-amber-700' : 'bg-f1-red text-white hover:bg-red-700'}`}
            aria-pressed={isSimulating}
          >
            {isSimulating ? (
              <Pause size={12} fill="currentColor" />
            ) : (
              <Play size={12} fill="currentColor" />
            )}
            {isSimulating ? 'PAUSE TELEMETRY' : 'START SIMULATION'}
          </button>
          
          <button
            onClick={onResetSim}
            className="flex items-center gap-1 bg-white/5 border border-white/10 text-on-surface-variant px-3 py-2 font-mono font-bold text-xs rounded hover:bg-white/10 transition-colors uppercase"
          >
            <RotateCcw size={12} />
            RESET
          </button>
        </div>
        
        <div className="flex flex-wrap gap-4 text-xs font-mono">
          <div className="flex items-center gap-1 text-white/50">
            <span className="w-2.5 h-2.5 rounded-full bg-purple-400 inline-block" />
            <span>SESSION BEST</span>
          </div>
          <div className="flex items-center gap-1 text-white/50">
            <span className="w-2.5 h-2.5 rounded-full bg-green-400 inline-block" />
            <span>PERSONAL BEST</span>
          </div>
          <div className="flex items-center gap-1 text-white/50">
            <span className="w-2.5 h-2.5 rounded-full bg-yellow-400 inline-block" />
            <span>YELLOW SECTOR</span>
          </div>
        </div>
      </div>

      {/* Main Leaderboard Table */}
      <div className="carbon-card rounded-lg overflow-x-auto">
        <table className="w-full text-left font-mono border-collapse min-w-[800px]">
          <thead>
            <tr className="bg-surface-container text-[11px] font-black text-on-surface-variant uppercase tracking-wider border-b border-white/10">
              <th className="py-3 px-4 w-12 text-center">POS</th>
              <th className="py-3 px-2 w-10">NO</th>
              <th className="py-3 px-3">DRIVER/TEAM</th>
              <th className="py-3 px-4 w-28">GAP TO LEADER</th>
              <th className="py-3 px-3 w-28 text-center">STATUS</th>
              <th className="py-3 px-4 text-right">LAST LAP</th>
              <th className="py-3 px-4 text-center">SECTOR 1</th>
              <th className="py-3 px-4 text-center">SECTOR 2</th>
              <th className="py-3 px-4 text-center">SECTOR 3</th>
              <th className="py-3 px-4 text-center w-28">TYRES</th>
              <th className="py-3 px-3 text-center">PITS</th>
            </tr>
          </thead>
          <tbody>
            {sortedDrivers.map((driver) => {
              const tyreSpec = getTyreStyle(driver.tyre);
              const isSelected = selectedDriver?.id === driver.id;
              
              return (
                <tr
                  key={driver.id}
                  onClick={() => setSelectedDriver(driver)}
                  className={`cursor-pointer transition-colors duration-150 border-b border-white/5 hover:bg-white/5 align-middle ${isSelected ? 'bg-white/10 text-white font-semibold' : 'text-on-surface/90'}`}
                >
                  {/* Position */}
                  <td className="py-3 text-center font-bold relative">
                    {/* Active highlight color rail */}
                    {isSelected && (
                      <div className="absolute left-0 top-0 bottom-0 w-1 bg-f1-red" />
                    )}
                    <span className={driver.currentPosition <= 3 ? 'text-f1-red font-black font-sans italic text-sm' : 'text-on-surface-variant'}>
                      {driver.currentPosition}
                    </span>
                  </td>

                  {/* Car Number */}
                  <td className="py-3 px-2">
                    <span className="text-[11px] text-white/50 font-bold">
                      {driver.number}
                    </span>
                  </td>

                  {/* Driver Name & Team Color Bar */}
                  <td className="py-3 px-3">
                    <div className="flex items-center gap-3">
                      <div className="w-1 h-5 rounded-full" style={{ backgroundColor: driver.teamColor }} />
                      <div className="flex flex-col">
                        <span className="font-sans font-extrabold text-sm text-on-surface">
                          {driver.code}
                          <span className="font-mono text-xs text-white/40 font-normal ml-2 hidden lg:inline">
                            {driver.name}
                          </span>
                        </span>
                        <span className="text-[10px] text-on-surface-variant/70 uppercase">
                          {driver.team}
                        </span>
                      </div>
                    </div>
                  </td>

                  {/* Gap to Leader */}
                  <td className="py-3 px-4 font-mono text-xs font-bold text-on-surface/80">
                    {driver.gapToLeader === 'INTERVAL' ? (
                      <span className="text-[10px] bg-white/5 text-white/50 px-1 rounded">INTERVAL</span>
                    ) : (
                      driver.gapToLeader
                    )}
                  </td>

                  {/* Driver Status Pin */}
                  <td className="py-3 px-3 text-center text-xs">
                    {driver.status === 'pitting' ? (
                      <span className="inline-block bg-amber-600/10 border border-amber-600/30 text-amber-500 font-extrabold px-1.5 py-0.5 rounded text-[10px] tracking-wide animate-pulse uppercase">
                        IN PIT LANE
                      </span>
                    ) : driver.status === 'retired' ? (
                      <span className="inline-block bg-red-950/35 border border-red-900/30 text-red-500/80 font-bold px-1.5 py-0.5 rounded text-[10px] tracking-wide uppercase">
                        RETIRED
                      </span>
                    ) : (
                      <span className="inline-block bg-emerald-500/10 border border-emerald-500/25 text-emerald-500 px-1.5 py-0.5 rounded text-[10px] tracking-wide font-bold uppercase">
                        ON TRACK
                      </span>
                    )}
                  </td>

                  {/* Last Lap Time */}
                  <td className="py-3 px-4 text-right font-bold text-xs text-on-surface">
                    {driver.lastLapTime}
                  </td>

                  {/* Sector 1 */}
                  <td className="py-3 px-4 text-center font-bold text-xs">
                    <span className={getSectorStyle(driver.sector1State)}>
                      {driver.sector1.toFixed(3)}
                    </span>
                  </td>

                  {/* Sector 2 */}
                  <td className="py-3 px-4 text-center font-bold text-xs">
                    <span className={getSectorStyle(driver.sector2State)}>
                      {driver.sector2.toFixed(3)}
                    </span>
                  </td>

                  {/* Sector 3 */}
                  <td className="py-3 px-4 text-center font-bold text-xs">
                    <span className={getSectorStyle(driver.sector3State)}>
                      {driver.sector3.toFixed(3)}
                    </span>
                  </td>

                  {/* Tyres Compound + Age */}
                  <td className="py-3 px-4 text-center text-xs">
                    <div className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded border" style={{ borderColor: 'rgba(255,255,255,0.06)' }}>
                      <span className={`w-2 h-2 rounded-full ${tyreSpec.dot}`} />
                      <span className="font-extrabold text-[10px]">{tyreSpec.label}</span>
                      <span className="text-[9px] text-white/40">({driver.tyreAge}L)</span>
                    </div>
                  </td>

                  {/* Pitstop Count */}
                  <td className="py-3 px-3 text-center text-xs font-bold text-on-surface-variant">
                    {driver.pitStops}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Speed Trap Bulletin overlay */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="bg-surface-low border border-white/5 rounded p-3 flex justify-between items-center text-xs">
          <span className="text-on-surface-variant font-mono">SECTOR 1 GAP TRAP</span>
          <span className="text-purple-400 font-bold">VER 326.8 km/h</span>
        </div>
        <div className="bg-surface-low border border-white/5 rounded p-3 flex justify-between items-center text-xs">
          <span className="text-on-surface-variant font-mono">SECTOR 2 HIGH G-ZONE</span>
          <span className="text-green-400 font-bold">LEC 4.2 G</span>
        </div>
        <div className="bg-surface-low border border-white/5 rounded p-3 flex justify-between items-center text-xs">
          <span className="text-on-surface-variant font-mono">TYRE SLIP % COEFFICIENT</span>
          <span className="text-white/60">AVG 1.2% (OPTIMAL)</span>
        </div>
      </div>

    </div>
  );
}
