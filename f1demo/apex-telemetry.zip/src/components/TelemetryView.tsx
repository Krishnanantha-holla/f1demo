import { useState, useEffect } from 'react';
import { Driver } from '../types';
import { Radio, Activity } from 'lucide-react';

interface TelemetryViewProps {
  drivers: Driver[];
  selectedDriver: Driver | null;
  setSelectedDriver: (driver: Driver | null) => void;
}

export default function TelemetryView({
  drivers,
  selectedDriver,
  setSelectedDriver,
}: TelemetryViewProps) {
  // Let user pick a compare driver (default to second driver in standings)
  const availableCompareDrivers = drivers.filter(d => d.id !== selectedDriver?.id);
  const [compareDriverId, setCompareDriverId] = useState<string>(availableCompareDrivers[0]?.id || 'lec');
  
  const compDriver = drivers.find(d => d.id === compareDriverId) || availableCompareDrivers[0];
  const primaryDriver = selectedDriver || drivers[0];

  // We keep a small local ring buffer of telemetry history points for the trace graph
  const [telemetryHistory, setTelemetryHistory] = useState<{
    time: number;
    pSpeed: number;
    pThrottle: number;
    pBrake: number;
    cSpeed: number;
    cThrottle: number;
    cBrake: number;
  }[]>([]);

  useEffect(() => {
    // Generate some history points initially if empty
    if (telemetryHistory.length === 0) {
      const initial: typeof telemetryHistory = [];
      for (let i = 0; i < 30; i++) {
        const pFactor = Math.sin(i / 5);
        const cFactor = Math.cos(i / 6.5);
        initial.push({
          time: i,
          pSpeed: 180 + pFactor * 80 + Math.random() * 10,
          pThrottle: Math.max(0, Math.floor(50 + pFactor * 50)),
          pBrake: Math.max(0, Math.floor(0 - pFactor * 100)),
          cSpeed: 190 + cFactor * 75 + Math.random() * 10,
          cThrottle: Math.max(0, Math.floor(60 + cFactor * 40)),
          cBrake: Math.max(0, Math.floor(0 - cFactor * 100))
        });
      }
      setTelemetryHistory(initial);
    }
  }, []);

  // Update history buffer on primary/comp driver values dynamic change
  useEffect(() => {
    if (!primaryDriver) return;
    
    const timer = setInterval(() => {
      setTelemetryHistory(prev => {
        // Drop oldest and push new point
        const nextTime = prev.length > 0 ? prev[prev.length - 1].time + 1 : 0;
        const updated = [...prev.slice(1)];
        updated.push({
          time: nextTime,
          pSpeed: primaryDriver.speed,
          pThrottle: primaryDriver.throttle,
          pBrake: primaryDriver.brake,
          cSpeed: compDriver ? compDriver.speed : 0,
          cThrottle: compDriver ? compDriver.throttle : 0,
          cBrake: compDriver ? compDriver.brake : 0
        });
        return updated;
      });
    }, 200);

    return () => clearInterval(timer);
  }, [primaryDriver, compDriver]);

  // SVG Gauge calculations
  const polarToCartesian = (centerX: number, centerY: number, radius: number, angleInDegrees: number) => {
    const angleInRadians = ((angleInDegrees - 90) * Math.PI) / 180.0;
    return {
      x: centerX + radius * Math.cos(angleInRadians),
      y: centerY + radius * Math.sin(angleInRadians),
    };
  };

  const describeArc = (x: number, y: number, radius: number, startAngle: number, endAngle: number) => {
    const start = polarToCartesian(x, y, radius, endAngle);
    const end = polarToCartesian(x, y, radius, startAngle);
    const largeArcFlag = endAngle - startAngle <= 180 ? '0' : '1';
    return [
      'M', start.x, start.y,
      'A', radius, radius, 0, largeArcFlag, 0, end.x, end.y
    ].join(' ');
  };

  // Helper inside loop for history traces
  const maxHistoryPoints = telemetryHistory.length;

  return (
    <div className="flex flex-col gap-5 animate-fade-in">
      
      {/* Comparator Header Config */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center bg-surface-container p-4 rounded-lg border border-white/5 gap-3">
        <div className="flex items-center gap-2">
          <Activity size={16} className="text-f1-red animate-pulse" />
          <span className="font-sans font-extrabold text-sm text-on-surface">
            ENGINEERING LAP TELEMETRY COMPARATOR
          </span>
        </div>
        
        <div className="flex flex-wrap items-center gap-3">
          {/* Primary selector */}
          <div className="flex items-center gap-2">
            <span className="font-mono text-[10px] text-on-surface-variant uppercase">PRIMARY DRIVER:</span>
            <select
              value={primaryDriver.id}
              onChange={(e) => {
                const found = drivers.find(d => d.id === e.target.value);
                if (found) setSelectedDriver(found);
              }}
              className="bg-black/45 border border-white/10 rounded px-2 py-1 font-mono text-xs text-white uppercase focus:border-f1-red focus:outline-none"
            >
              {drivers.map(d => (
                <option key={d.id} value={d.id}>{d.code} - {d.name}</option>
              ))}
            </select>
          </div>

          <span className="text-white/20 hidden sm:inline">|</span>

          {/* Secondary compare selector */}
          <div className="flex items-center gap-2">
            <span className="font-mono text-[10px] text-on-surface-variant uppercase">COMPARISON:</span>
            <select
              value={compareDriverId}
              onChange={(e) => setCompareDriverId(e.target.value)}
              className="bg-black/45 border border-white/10 rounded px-2 py-1 font-mono text-xs text-white uppercase focus:border-f1-red focus:outline-none"
            >
              {drivers.map(d => (
                <option key={d.id} value={d.id}>{d.code} - {d.name}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Dials Side-by-Side Comparison Container */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        
        {/* PRIMARY DRIVER TELEMETRY DASHBOARD */}
        <div className="carbon-card rounded-lg p-5 flex flex-col gap-4 border-t-2" style={{ borderTopColor: primaryDriver.teamColor }}>
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-2.5">
              <span className="w-2 h-2 rounded-full" style={{ backgroundColor: primaryDriver.teamColor }} />
              <span className="font-sans font-black text-sm text-on-surface uppercase">{primaryDriver.name}</span>
            </div>
            <span className="font-mono text-[10px] bg-white/5 border border-white/5 text-on-surface-variant px-1.5 rounded">
              #{primaryDriver.number}
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-12 gap-4 items-center">
            {/* RPM / GEAR Dial Area */}
            <div className="col-span-1 sm:col-span-5 flex flex-col items-center">
              <div className="w-36 h-36 relative">
                {/* SVG Radial Speedometer Gauge */}
                <svg className="w-full h-full" viewBox="0 0 100 100">
                  {/* Gray background arc */}
                  <path
                    d={describeArc(50, 50, 42, -120, 120)}
                    fill="none"
                    stroke="rgba(255, 255, 255, 0.05)"
                    strokeWidth="5.5"
                    strokeLinecap="round"
                  />
                  {/* Primary team color colored active arc */}
                  <path
                    d={describeArc(50, 50, 42, -120, -120 + ((primaryDriver.rpm / 15000) * 240))}
                    fill="none"
                    stroke={primaryDriver.teamColor}
                    strokeWidth="6"
                    strokeLinecap="round"
                    className="transition-all duration-300"
                  />
                  {/* Outer ticks */}
                  <text x="50" y="32" className="fill-white/30 font-mono text-[9px] text-center" textAnchor="middle">RPM</text>
                  <text x="50" y="44" className="fill-white/40 font-mono text-[7px]" textAnchor="middle">{(primaryDriver.rpm).toLocaleString()}</text>
                  <text x="50" y="70" className="fill-white font-sans font-black text-3xl" textAnchor="middle">
                    {primaryDriver.gear === 0 ? 'N' : primaryDriver.gear}
                  </text>
                  <text x="50" y="82" className="fill-white/50 font-sans text-[7px] tracking-widest" textAnchor="middle">GEAR</text>
                </svg>
              </div>
            </div>

            {/* Speeds & Pedals Bar Area */}
            <div className="col-span-1 sm:col-span-7 flex flex-col gap-3 font-mono">
              {/* SPEED km/h */}
              <div className="bg-black/30 p-2.5 rounded border border-white/5">
                <div className="text-[10px] text-on-surface-variant uppercase">TELEMETRY SPEED</div>
                <div className="text-xl font-black text-on-surface mt-0.5">
                  {primaryDriver.speed} <span className="font-normal text-xs text-white/50">KM/H</span>
                </div>
              </div>

              {/* THROTTLE COMPOUND */}
              <div>
                <div className="flex justify-between text-xs">
                  <span className="text-on-surface-variant font-bold uppercase">Throttle Pedal %</span>
                  <span className="text-emerald-400 font-bold">{primaryDriver.throttle}%</span>
                </div>
                <div className="w-full bg-white/5 h-2 rounded mt-1.5 overflow-hidden">
                  <div
                    className="bg-emerald-500 h-full transition-all duration-150"
                    style={{ width: `${primaryDriver.throttle}%` }}
                  />
                </div>
              </div>

              {/* BRAKE COMPOUND */}
              <div>
                <div className="flex justify-between text-xs">
                  <span className="text-on-surface-variant font-bold uppercase">Braking Pressure %</span>
                  <span className="text-red-400 font-bold">{primaryDriver.brake}%</span>
                </div>
                <div className="w-full bg-white/5 h-2 rounded mt-1.5 overflow-hidden">
                  <div
                    className="bg-red-500 h-full transition-all duration-150"
                    style={{ width: `${primaryDriver.brake}%` }}
                  />
                </div>
              </div>
            </div>
          </div>
          
          <div className="flex justify-between text-[11px] font-mono text-on-surface-variant bg-white/5 p-2 rounded">
            <span>DRS: {primaryDriver.drs ? 'DRS-ACTIVE (OPEN)' : 'DRS-STATIC'}</span>
            <span>STEER: {primaryDriver.steering}°</span>
          </div>
        </div>

        {/* COMPARISON DRIVER TELEMETRY DASHBOARD */}
        <div className="carbon-card rounded-lg p-5 flex flex-col gap-4 border-t-2" style={{ borderTopColor: compDriver?.teamColor || '#ffffff' }}>
          {compDriver ? (
            <>
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-2.5">
                  <span className="w-2 h-2 rounded-full" style={{ backgroundColor: compDriver.teamColor }} />
                  <span className="font-sans font-black text-sm text-on-surface uppercase">{compDriver.name}</span>
                </div>
                <span className="font-mono text-[10px] bg-white/5 border border-white/5 text-on-surface-variant px-1.5 rounded">
                  #{compDriver.number}
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-12 gap-4 items-center">
                {/* RPM / GEAR Dial Area */}
                <div className="col-span-1 sm:col-span-5 flex flex-col items-center">
                  <div className="w-36 h-36 relative">
                    <svg className="w-full h-full" viewBox="0 0 100 100">
                      <path
                        d={describeArc(50, 50, 42, -120, 120)}
                        fill="none"
                        stroke="rgba(255, 255, 255, 0.05)"
                        strokeWidth="5.5"
                        strokeLinecap="round"
                      />
                      <path
                        d={describeArc(50, 50, 42, -120, -120 + ((compDriver.rpm / 15000) * 240))}
                        fill="none"
                        stroke={compDriver.teamColor}
                        strokeWidth="6"
                        strokeLinecap="round"
                        className="transition-all duration-300"
                      />
                      <text x="50" y="32" className="fill-white/30 font-mono text-[9px] text-center" textAnchor="middle">RPM</text>
                      <text x="50" y="44" className="fill-white/40 font-mono text-[7px]" textAnchor="middle">{(compDriver.rpm).toLocaleString()}</text>
                      <text x="50" y="70" className="fill-white font-sans font-black text-3xl" textAnchor="middle">
                        {compDriver.gear === 0 ? 'N' : compDriver.gear}
                      </text>
                      <text x="50" y="82" className="fill-white/50 font-sans text-[7px] tracking-widest" textAnchor="middle">GEAR</text>
                    </svg>
                  </div>
                </div>

                {/* Speeds & Pedals Bar Area */}
                <div className="col-span-1 sm:col-span-7 flex flex-col gap-3 font-mono">
                  <div className="bg-black/30 p-2.5 rounded border border-white/5">
                    <div className="text-[10px] text-on-surface-variant uppercase">TELEMETRY SPEED</div>
                    <div className="text-xl font-black text-on-surface mt-0.5">
                      {compDriver.speed} <span className="font-normal text-xs text-white/50">KM/H</span>
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between text-xs">
                      <span className="text-on-surface-variant font-bold uppercase">Throttle Pedal %</span>
                      <span className="text-emerald-400 font-bold">{compDriver.throttle}%</span>
                    </div>
                    <div className="w-full bg-white/5 h-2 rounded mt-1.5 overflow-hidden">
                      <div
                        className="bg-emerald-500 h-full transition-all duration-150"
                        style={{ width: `${compDriver.throttle}%` }}
                      />
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between text-xs">
                      <span className="text-on-surface-variant font-bold uppercase">Braking Pressure %</span>
                      <span className="text-red-400 font-bold">{compDriver.brake}%</span>
                    </div>
                    <div className="w-full bg-white/5 h-2 rounded mt-1.5 overflow-hidden">
                      <div
                        className="bg-red-500 h-full transition-all duration-150"
                        style={{ width: `${compDriver.brake}%` }}
                      />
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="flex justify-between text-[11px] font-mono text-on-surface-variant bg-white/5 p-2 rounded">
                <span>DRS: {compDriver.drs ? 'DRS-ACTIVE (OPEN)' : 'DRS-STATIC'}</span>
                <span>STEER: {compDriver.steering}°</span>
              </div>
            </>
          ) : (
            <div className="text-center font-mono py-12 text-on-surface-variant text-xs">
              Select comparison driver in header
            </div>
          )}
        </div>

      </div>

      {/* Live History Speed Trace Panel overlay */}
      <div className="carbon-card rounded-lg p-5">
        <div className="flex justify-between items-center border-b border-white/5 pb-3">
          <div className="flex items-center gap-2">
            <Radio size={14} className="text-f1-red animate-pulse" />
            <span className="font-mono text-xs font-bold tracking-wider text-on-surface-variant uppercase">
              LIVE SPEED TRACE COMPARE (LAST 30 BEACON TICK SHAKE-OUTS)
            </span>
          </div>
          
          <div className="flex gap-4 font-mono text-[10px]">
            <div className="flex items-center gap-1">
              <span className="w-2.5 h-1.5 rounded-sm inline-block" style={{ backgroundColor: primaryDriver?.teamColor || '#ffb4a8' }} />
              <span>{primaryDriver?.code} SPEED TRACE</span>
            </div>
            {compDriver && (
              <div className="flex items-center gap-1 animate-pulse">
                <span className="w-2.5 h-1.5 rounded-sm inline-block" style={{ backgroundColor: compDriver.teamColor }} />
                <span>{compDriver.code} SPEED TRACE</span>
              </div>
            )}
          </div>
        </div>

        {/* Dynamic Canvas/SVG Speed chart representation */}
        <div className="h-44 mt-4 relative w-full">
          {telemetryHistory.length > 0 ? (
            <svg className="w-full h-full overflow-visible" viewBox="0 0 300 100" preserveAspectRatio="none">
              {/* grid lines */}
              <line x1="0" y1="20" x2="300" y2="20" stroke="rgba(255,255,255,0.03)" strokeWidth="0.5" />
              <line x1="0" y1="50" x2="300" y2="50" stroke="rgba(255,255,255,0.03)" strokeWidth="0.5" />
              <line x1="0" y1="80" x2="300" y2="80" stroke="rgba(255,255,255,0.03)" strokeWidth="0.5" />
              
              {/* vertical grid tags */}
              <line x1="60" y1="0" x2="60" y2="100" stroke="rgba(255,255,255,0.03)" strokeWidth="0.5" />
              <line x1="120" y1="0" x2="120" y2="100" stroke="rgba(255,255,255,0.03)" strokeWidth="0.5" />
              <line x1="180" y1="0" x2="180" y2="100" stroke="rgba(255,255,255,0.03)" strokeWidth="0.5" />
              <line x1="240" y1="0" x2="240" y2="100" stroke="rgba(255,255,255,0.03)" strokeWidth="0.5" />

              {/* Primary driver trace path plot */}
              <polyline
                fill="none"
                stroke={primaryDriver?.teamColor || '#ffb4a8'}
                strokeWidth="2"
                points={telemetryHistory.map((p, index) => {
                  const x = (index / (maxHistoryPoints - 1)) * 300;
                  // Range speeds 50 to 330 maps to 90 to 10
                  const y = 90 - ((p.pSpeed - 50) / 280) * 80;
                  return `${x},${y}`;
                }).join(' ')}
                className="transition-all duration-150"
              />

              {/* Comparison driver trace path plot */}
              {compDriver && (
                <polyline
                  fill="none"
                  stroke={compDriver.teamColor}
                  strokeWidth="1.5"
                  strokeDasharray="2, 2"
                  points={telemetryHistory.map((p, index) => {
                    const x = (index / (maxHistoryPoints - 1)) * 300;
                    // Range speeds 50 to 330 maps to 90 to 10
                    const y = 90 - ((p.cSpeed - 50) / 280) * 80;
                    return `${x},${y}`;
                  }).join(' ')}
                  className="transition-all duration-150"
                />
              )}
            </svg>
          ) : (
            <div className="absolute inset-0 flex items-center justify-center font-mono text-xs text-on-surface-variant">
              Accumulating trace graphs...
            </div>
          )}

          {/* Left indicator speed tags */}
          <div className="absolute top-0 left-1 font-mono text-[8px] text-white/30 flex flex-col justify-between h-full pointer-events-none">
            <span>340 KM/H</span>
            <span>200 KM/H</span>
            <span>60 KM/H</span>
          </div>
          {/* Bottom timeline tags */}
          <div className="absolute bottom-1 right-2 font-mono text-[8px] text-white/20 uppercase pointer-events-none">
            Time Delta scale: -30 Seconds Buffer
          </div>
        </div>

      </div>

    </div>
  );
}
